from modelo import *
from argon2 import PasswordHasher
from modelo import *
ph = PasswordHasher()

def menu_usuario():
    while True:
        print("1 - Paquete Turistico y reservas\n"
              "2 - Opciones de usuario\n"
              "3 - cerrar sesión de usuario\n")
        
        operacion = int(input("Ingrese numero de opción: "))
        
        
        if operacion == 1:
           menu_reserva()
        elif operacion == 2:
            opciones_usuario()
            
        elif operacion == 3:
            break
        
        else:
            print("opción invalida")


def menu_reserva():
    while True:
        print("Aqui puedes ver y reservar todos los paquetes turisticos disponibles\n")
        
        PaqueteTuristico.mostrarPaquetes()
        
        print("\nPuedes realizar las siguientes opciones:\n"
                    "1 - Realizar Reserva\n"
                    "2 - Ver reserva\n"
                    "3 - Cancelar reserva\n"
                    "4 - Salir")
         
        opcion = int(input("Escriba el numero de la acción que desea realizar: "))

        if opcion == 1:
            PaqueteTuristico.mostrarPaquetes()
            
            print("\n1 - Ver precio total del paquete\n"
                  "2 - Salir\n")
            op = int(input("Ingrese numero de opción: "))
            
            if op == 1:
                PaqueteTuristico.mostrarPaquetes()
                paquete_turistico = input("Ingrese nombre del paquete que desea: ")
                paquete = PaqueteTuristico(paquete_turistico, '', '', 0)
                paquete.VerPrecioTotal(paquete_turistico)

                print("1 - Reservar\n"
                      "2 - Salir\n")
                
                op == int(input("Desea reservar el paquete turistico?: "))
                
                if op == 1:
                    usuario = input('ingrese nombre de usuario: ')
                    contrasenia = input('ingrese contrasenia: ')
                    Reserva.CrearReserva(paquete_turistico, usuario, contrasenia)
                else:
                    print("gracias por visitarnos, vuelve pronto")

        elif opcion == 2:
            usuario = input('ingrese nombre de usuario: ')
            contrasenia = input('ingrese contrasenia: ')
            acceso = Usuario.AutorizarUsuario(usuario, contrasenia)
            if acceso == True:
                Reserva.VerReserva(usuario)
            else:
                print("No tiene reserva agendada")

        elif opcion == 3:
            usuario = input('ingrese usuario: ')
            contrasenia = input('ingrese contrasenia: ')
            acceso = Usuario.AutorizarUsuario(usuario, contrasenia)
            if acceso == True:
                Reserva.VerReserva(usuario)
                nombre_pt = input("Ingrese el nombre del paquete reservado que quiere cancelar: ")
                Reserva.CancelarReserva(usuario, nombre_pt)
            else:
                print("No tiene reserva agendada")
        
        elif opcion == 4:
            break
        
        else:
            print("opción erronea")
            
def opciones_usuario():
    pass



                    